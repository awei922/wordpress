const path = require('path')
const srcPath = path.join(__dirname, '..', '');
const distPath = path.join(__dirname, '..', 'assets');

module.exports = {
    srcPath,
    distPath
}
