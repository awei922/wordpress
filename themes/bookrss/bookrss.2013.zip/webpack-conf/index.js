// css
import '../assets/scss/style.scss'

// js
import '../assets/js/highlight.pack.js'
import '../assets/js/custom'
